# Leapfrog Bolt Pro - Klipper Setup Guide

This package contains all necessary files and documentation to run Klipper firmware on the Leapfrog Bolt Pro printer.

## Contents
- configs/printer.cfg
- configs/macros.cfg
- scripts/led_state.py
- scripts/powerbutton.py
- scripts/update_klipper.sh

## Installation
Follow the full guide in the README section provided by ChatGPT.
